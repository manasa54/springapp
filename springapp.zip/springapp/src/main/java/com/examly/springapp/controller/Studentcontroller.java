package com.examly.springapp.controller;

public class Studentcontroller {
}

package com.examly.springapp.service;

public interface Studentservice {
}
